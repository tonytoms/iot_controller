import time

while True:
    a=2
    print(a)
    time.sleep( 2 )