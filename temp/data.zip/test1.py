import time

while True:
    a=1
    print(a)
    time.sleep( 2 )